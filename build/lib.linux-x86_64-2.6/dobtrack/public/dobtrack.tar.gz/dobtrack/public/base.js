;
if (typeof DOB_BASE === "undefined") var DOB_BASE = {};

DOB_BASE.init = function() {

};

$(document).ready(DOB_BASE.init);