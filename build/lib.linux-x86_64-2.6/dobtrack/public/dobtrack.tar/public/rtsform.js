;
if (typeof DOB_RTSFORM === "undefined") var DOB_RTSFORM = {
    clickedok: false
};

DOB_RTSFORM.init = function() {
  window.print();
}

$(document).ready(DOB_RTSFORM.init);
